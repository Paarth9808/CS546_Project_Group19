export const mongoConfig = {
    //serverUrl: 'mongodb://localhost:27017/',
    // for my device only url
    serverUrl: 'mongodb://127.0.0.1:27017/',
    database: 'Game_Review_DB'
  };