import gameDataFunctions from './games.js'
import userDataFunctions from './user.js'
import gameListDataFunctions from './gameList.js';

export const gameData=gameDataFunctions,userData=userDataFunctions;
export const gameListData = gameListDataFunctions;
