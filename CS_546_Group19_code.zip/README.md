GAME REVIEW SYSTEM
Steps to run the project:
1. Open the folder and run npm i
2. Run the seed file - node seed.js
3. Run the application - npm start

The seed file creates an admin user and a few other normal users.
Credentials for admin user: admin@gmail.com/Password@1   
Credentials for a regular user: test1@gmail.com/Password@1

