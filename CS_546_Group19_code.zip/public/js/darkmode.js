document.getElementById('toggleDarkMode').onclick = () => {
  var element = document.body;
  element.classList.toggle("dark-mode");
}